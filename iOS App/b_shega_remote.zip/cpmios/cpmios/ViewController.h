//
//  ViewController.h
//  cpmios
//
//  Created by Brandon Shega on 7/9/14.
//  Copyright (c) 2014 Brandon Shega. All rights reserved.
//  Cross-Platform Mobile Development 1407
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface ViewController : UIViewController <PFLogInViewControllerDelegate, PFSignUpViewControllerDelegate>

- (IBAction)logoutButton:(id)sender;

@end
